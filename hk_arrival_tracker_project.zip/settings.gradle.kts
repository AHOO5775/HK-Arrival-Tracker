rootProject.name = "hk-arrival-tracker"
include(":app")
