package com.example.hkarrival.ui

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.hkarrival.data.Arrival
import com.example.hkarrival.viewmodel.ArrivalViewModel
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun ArrivalApp(vm: ArrivalViewModel = viewModel()) {
    val today = LocalDate.now().format(DateTimeFormatter.ISO_DATE)
    var selectedDate by remember { mutableStateOf(today) }
    val arrivals by vm.arrivalsForDate(selectedDate).collectAsState(initial = emptyList())

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text(text = "HK Arrival Tracker", style = MaterialTheme.typography.h5)
        Spacer(Modifier.height(8.dp))

        DateSelector(selectedDate) { selectedDate = it; vm.loadForDate(it) }
        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Button(onClick = { vm.addSample(selectedDate) }) { Text("+ Add") }
            Button(onClick = { /* Show import dialog */ }) { Text("Paste from Excel") }
        }

        Spacer(Modifier.height(12.dp))
        Text("Arrivals for $selectedDate", style = MaterialTheme.typography.subtitle1)
        Spacer(Modifier.height(8.dp))

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(arrivals) { a -> ArrivalRow(a, vm) }
        }
    }
}

@Composable
fun DateSelector(current: String, onChange: (String) -> Unit) {
    val ctx = LocalContext.current
    val date = LocalDate.parse(current)
    Button(onClick = {
        val dp = DatePickerDialog(ctx, { _, y, m, d ->
            val formatted = LocalDate.of(y, m + 1, d).format(DateTimeFormatter.ISO_DATE)
            onChange(formatted)
        }, date.year, date.monthValue - 1, date.dayOfMonth)
        dp.show()
    }) { Text(current) }
}

@Composable
fun ArrivalRow(a: Arrival, vm: ArrivalViewModel) {
    Card(modifier = Modifier.fillMaxWidth().padding(4.dp)) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Room ${a.roomNumber}")
                Text(a.arrivalTimeIso ?: "—")
            }
            Spacer(Modifier.height(6.dp))
            Row {
                Checkbox(checked = a.cleaned, onCheckedChange = { vm.setCleaned(a.id, it) })
                Text("Cleaned")
                Spacer(Modifier.width(8.dp))
                Checkbox(checked = a.inspected, onCheckedChange = { vm.setInspected(a.id, it) })
                Text("Inspected")
            }
            Spacer(Modifier.height(6.dp))
            if (!a.specialNotes.isNullOrEmpty()) Text("Notes: ${a.specialNotes}")
        }
    }
}
