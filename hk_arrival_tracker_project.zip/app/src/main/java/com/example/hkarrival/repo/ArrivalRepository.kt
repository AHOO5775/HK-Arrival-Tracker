package com.example.hkarrival.repo

import com.example.hkarrival.data.Arrival
import com.example.hkarrival.data.ArrivalDao
import kotlinx.coroutines.flow.Flow

class ArrivalRepository(private val dao: ArrivalDao) {
    fun arrivalsForDate(dateIso: String): Flow<List<Arrival>> = dao.arrivalsForDateFlow(dateIso)
    suspend fun insert(arrival: Arrival) = dao.insert(arrival)
    suspend fun update(arrival: Arrival) = dao.update(arrival)
    suspend fun delete(arrival: Arrival) = dao.delete(arrival)
    suspend fun pendingInspections() = dao.pendingInspections()
    // expose dao for ViewModel convenience (small scaffold)
    val daoRef: ArrivalDao get() = dao
}
