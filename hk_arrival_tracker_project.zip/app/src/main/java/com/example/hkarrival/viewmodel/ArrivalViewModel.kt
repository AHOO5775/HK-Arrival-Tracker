package com.example.hkarrival.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.hkarrival.data.AppDatabase
import com.example.hkarrival.data.Arrival
import com.example.hkarrival.repo.ArrivalRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.time.LocalTime

class ArrivalViewModel(application: Application): AndroidViewModel(application) {
    private val repo: ArrivalRepository

    init {
        val db = AppDatabase.getInstance(application)
        repo = ArrivalRepository(db.arrivalDao())
    }

    fun arrivalsForDate(dateIso: String): Flow<List<Arrival>> = repo.arrivalsForDate(dateIso)

    fun loadForDate(dateIso: String) { /* nothing needed here when using Flow */ }

    fun addSample(dateIso: String) = viewModelScope.launch {
        val a = Arrival(
            dateIso = dateIso,
            arrivalTimeIso = LocalTime.now().toString(),
            departureTimeIso = null,
            roomNumber = "101",
            villaMoveTo = null,
            specialNotes = "VIP setup",
            comments = null
        )
        repo.insert(a)
    }

    fun setCleaned(id: Long, cleaned: Boolean) = viewModelScope.launch {
        val arr = repo.daoRef.getById(id) ?: return@launch
        repo.update(arr.copy(cleaned = cleaned))
    }

    fun setInspected(id: Long, inspected: Boolean) = viewModelScope.launch {
        val arr = repo.daoRef.getById(id) ?: return@launch
        repo.update(arr.copy(inspected = inspected))
    }
}
