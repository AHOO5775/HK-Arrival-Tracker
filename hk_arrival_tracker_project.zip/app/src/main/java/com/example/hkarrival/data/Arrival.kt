package com.example.hkarrival.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "arrivals")
data class Arrival(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateIso: String, // yyyy-MM-dd
    val arrivalTimeIso: String?, // ISO-8601 time or full datetime
    val departureTimeIso: String?,
    val roomNumber: String,
    val villaMoveTo: String?,
    val cleaned: Boolean = false,
    val inspected: Boolean = false,
    val maintenanceNeeded: Boolean = false,
    val released: Boolean = false,
    val specialNotes: String?,
    val comments: String?
)
