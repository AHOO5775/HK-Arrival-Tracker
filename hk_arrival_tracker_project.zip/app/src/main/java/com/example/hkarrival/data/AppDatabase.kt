package com.example.hkarrival.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Arrival::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun arrivalDao(): ArrivalDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val inst = Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "hk_arrivals.db").build()
                INSTANCE = inst
                inst
            }
        }
    }
}
