package com.example.hkarrival.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ArrivalDao {
    @Query("SELECT * FROM arrivals WHERE dateIso = :date ORDER BY arrivalTimeIso")
    fun arrivalsForDateFlow(date: String): Flow<List<Arrival>>

    @Query("SELECT * FROM arrivals WHERE id = :id")
    suspend fun getById(id: Long): Arrival?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(arrival: Arrival): Long

    @Update
    suspend fun update(arrival: Arrival)

    @Delete
    suspend fun delete(arrival: Arrival)

    @Query("SELECT * FROM arrivals WHERE inspected = 0 AND arrivalTimeIso IS NOT NULL")
    suspend fun pendingInspections(): List<Arrival>
}
